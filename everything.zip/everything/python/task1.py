from math import *
x = float(input())
y = float(input())
A = ((8*y+1)/(x*x+sin(x+y)))+3*cos(x)
B = (cos(x)+cos(y**(x+y)**1/3))/8
print(round(A,2),round(B,2),sep="B")