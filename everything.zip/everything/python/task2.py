from math import *
x = float(input())
y = float(input())
if(x>=0):
    print(round(log((x+0.3)**2),2))
else:
    print(round((x+y)**(0.7*x)**1/2,2))