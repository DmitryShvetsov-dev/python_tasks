from math import *
i = -3
while i <=3.3:
    print((i*i+cos(i+3))/2)
    i+=0.21