from collections import Counter
text = input()
textList = []
for i in text:
    textList.append(i)
counter = Counter(textList)
i = 0
while i < 10:
    strI = str(i)
    print(i,":",i*counter[strI])
    i+=1