from collections import Counter
text = input()
textList = []
for i in text:
    textList.append(i)
counter = Counter(textList)
print("a:",counter["a"],
"e:",counter["e"],
"y:",counter["y"],
"u:",counter["u"],
"j:",counter["j"],
"i:",counter["i"],
"o:",counter["o"])