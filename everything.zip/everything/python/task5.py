def monotone(n):
    a_n = (2*n*n+1)/(n*n-11)
    a_nPlus1 = (2*(n+1)*(n+1)+1)/((n+1)*(n+1)-11)
    if (x==y):
        print("The sequence is constant")
    else: 
        print("The sequence is monotonic")
n = int(input())
monotone(n)
