from math import sqrt

class GeometricFigure:
    def __init__(self,name,argument_1,argument_2,argument_3):
        self.name = name
        self.argument_1 = argument_1
        self.argument_2 = argument_2
        self.argument_3 = argument_2

class Circle(GeometricFigure):
    def area(self):
        print(self.name + "area: " + 3.14*self.argument_1*self.argument_1)
    def perimeter(self):
        print(self.name + "perimeter: " + 2*3.14*self.argument_1)

class Rectangle(GeometricFigure):
    def area(self):
        print(self.name + "area: " + self.argument_1*self.argument_2)
    def perimeter(self):
        print(self.name + "perimeter: " + 2*(self.argument_1+self.argument_2))

class Triangle(GeometricFigure):
    def area(self):
        print(self.name + "area: " + (math.sqrt((self.argument_1+self.argument_2+self.argument_3)/2)*
        ((self.argument_1+self.argument_2+self.argument_3)-self.argument_1)*
        ((self.argument_1+self.argument_2+self.argument_3)-self.argument_2)*
        ((self.argument_1+self.argument_2+self.argument_3)-self.argument_3)))
    def perimeter(self):
        print(self.name + "perimeter: " + self.argument_1+self.argument_2+self.argument_3)

shapeName = input("Please, write the name of the shape:\ncircle\nrectangle\ntriangle\n")
if(shapeName == "circle"):
    radius = float(input("Please, enter a radius:\n"))
    CircleObjectInit = GeometricFigure(shapeName,radius,0,0)
    CircleObject = Circle()
    print(CircleObject.area())
    print(CircleObject.perimeter())
if(shapeName == "rectangle"):
    argument_1,argument_2= map(int, input("Please,enter the length of the sides separated by a space:\n").split())
    RectangleObject = GeometricFigure(shapeName,argument_1,argument_2,0)
    print(RectangleObject.area())
    print(RectangleObject.perimeter())
if(shapeName == "triangle"):
    argument_1,argument_2,argument_3= map(int, input("Please,enter the length of the sides separated by a space:\n").split())
    TriangleObject = GeometricFigure(shapeName,argument_1,argument_2,argument_3)
    print(TriangleObject.area())
    print(TriangleObject.perimeter())
